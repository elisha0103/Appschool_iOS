//
//  MainCategoryView.swift
//  shortpingMVP
//
//  Created by 염성필 on 2022/12/21.
//

import SwiftUI

struct MainCategoryView: View {
    
    @State private var mainCategoryTitle: String = ""
    
    var body: some View {
        Text("123")
    }
}

struct MainCategoryView_Previews: PreviewProvider {
    static var previews: some View {
        MainCategoryView()
    }
}
