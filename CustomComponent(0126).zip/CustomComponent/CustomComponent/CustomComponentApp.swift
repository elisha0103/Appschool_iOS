//
//  CustomComponentApp.swift
//  CustomComponent
//
//  Created by 진태영 on 2023/01/24.
//

import SwiftUI

@main
struct CustomComponentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
